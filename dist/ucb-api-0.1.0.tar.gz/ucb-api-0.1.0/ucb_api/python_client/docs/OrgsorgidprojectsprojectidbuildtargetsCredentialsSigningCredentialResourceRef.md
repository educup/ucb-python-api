# OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRef

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | **str** |  | [optional] 
**label** | **str** |  | [optional] 
**credentialid** | **str** |  | [optional] 
**created** | **str** |  | [optional] 
**last_mod** | **str** |  | [optional] 
**certificate** | [**OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRefCertificate**](OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRefCertificate.md) |  | [optional] 
**provisioning_profile** | [**OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRefProvisioningProfile**](OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRefProvisioningProfile.md) |  | [optional] 
**keystore** | [**OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRefKeystore**](OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRefKeystore.md) |  | [optional] 
**links** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


