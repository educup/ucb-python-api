# OrgsorgidprojectsprojectidbuildtargetsLastBuilt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unity_version** | **str** | Last Unity version built by this target. Setting this has no effect. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


