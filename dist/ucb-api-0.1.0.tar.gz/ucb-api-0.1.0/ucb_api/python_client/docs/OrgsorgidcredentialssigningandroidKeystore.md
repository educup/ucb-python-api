# OrgsorgidcredentialssigningandroidKeystore

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alias** | **str** | friendly name for keystore | [optional] 
**debug** | **bool** | whether this is a debug or production keystore | [optional] 
**expiration** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


