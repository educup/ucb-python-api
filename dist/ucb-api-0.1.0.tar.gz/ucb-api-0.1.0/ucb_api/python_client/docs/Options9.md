# Options9

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clean** | **bool** |  | [optional] 
**delay** | **float** |  | [optional] 
**commit** | **str** |  | [optional] 
**headless** | **bool** | Only valid for local builds  | [optional] 
**label** | **str** | Only valid for local builds  | [optional] 
**platform** | **str** | Only valid for local builds  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


