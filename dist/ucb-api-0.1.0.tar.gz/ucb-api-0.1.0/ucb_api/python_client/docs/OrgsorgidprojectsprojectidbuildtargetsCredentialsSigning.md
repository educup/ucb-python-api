# OrgsorgidprojectsprojectidbuildtargetsCredentialsSigning

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credentialid** | **str** |  | [optional] 
**credential_resource_ref** | [**OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRef**](OrgsorgidprojectsprojectidbuildtargetsCredentialsSigningCredentialResourceRef.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


