# OrgsorgidprojectsprojectidbuildtargetsTestResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_test** | **object** |  | [optional] 
**unit_test_editmode** | **object** |  | [optional] 
**unit_test_playmode** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


