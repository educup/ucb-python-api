# Options1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**udid** | **str** |  | 
**devicename** | **str** |  | [optional] 
**os** | **str** |  | [optional] 
**osversion** | **str** |  | [optional] 
**product** | **str** |  | [optional] 
**status** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


