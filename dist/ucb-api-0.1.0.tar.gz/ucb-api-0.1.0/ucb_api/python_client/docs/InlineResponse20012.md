# InlineResponse20012

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **str** |  | [optional] 
**redirect** | **str** |  | [optional] 
**priority** | **int** |  | [optional] 
**scm_type** | **str** |  | [optional] 
**billing_plan** | **str** |  | [optional] 
**platform** | **str** |  | [optional] 
**alert_type** | **str** |  | [optional] 
**auto_clear** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


