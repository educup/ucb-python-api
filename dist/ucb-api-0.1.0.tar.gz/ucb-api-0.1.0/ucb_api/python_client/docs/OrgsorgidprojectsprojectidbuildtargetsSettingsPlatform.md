# OrgsorgidprojectsprojectidbuildtargetsSettingsPlatform

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bundle_id** | **str** | a unique identifier (com.example.name) | [optional] 
**xcode_version** | **str** | &#39;latest&#39; or a supported xcode version (ex. &#39;xcode7&#39;) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


