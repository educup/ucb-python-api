# InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updating_user_email** | **str** |  | [optional] 
**updated** | **str** |  | 
**lines** | [**list[OrgsorgidprojectsprojectidauditlogLines]**](OrgsorgidprojectsprojectidauditlogLines.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


