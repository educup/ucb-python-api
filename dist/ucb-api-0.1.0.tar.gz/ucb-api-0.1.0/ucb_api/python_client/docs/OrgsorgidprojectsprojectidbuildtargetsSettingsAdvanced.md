# OrgsorgidprojectsprojectidbuildtargetsSettingsAdvanced

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**xcode** | [**OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedXcode**](OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedXcode.md) |  | [optional] 
**android** | [**OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedAndroid**](OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedAndroid.md) |  | [optional] 
**unity** | [**OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnity**](OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


