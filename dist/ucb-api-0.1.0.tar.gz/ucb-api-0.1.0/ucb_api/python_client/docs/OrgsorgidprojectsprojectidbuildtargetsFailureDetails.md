# OrgsorgidprojectsprojectidbuildtargetsFailureDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **str** |  | [optional] 
**resolution_hint** | **str** |  | [optional] 
**stages** | **list[str]** |  | [optional] 
**failure_type** | **str** |  | [optional] 
**count** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


