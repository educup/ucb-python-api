# OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnityPlayerSettingsAndroid

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**use_apk_expansion_files** | **bool** | break up android apk into an installable apk and expansion files | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


