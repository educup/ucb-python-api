# Options7

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**platform** | **str** |  | [optional] 
**enabled** | **bool** |  | [optional] 
**settings** | [**OrgsorgidprojectsprojectidbuildtargetsSettings**](OrgsorgidprojectsprojectidbuildtargetsSettings.md) |  | [optional] 
**credentials** | [**OrgsorgidprojectsprojectidbuildtargetsCredentials1**](OrgsorgidprojectsprojectidbuildtargetsCredentials1.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


