# OrgsorgidcredentialssigningosxCertificate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cert_name** | **str** |  | [optional] 
**expiration** | **str** | expiration date | [optional] 
**uploaded** | **str** | uploaded date | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


