# OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnityAddressablesContentUpdateSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_state_path** | **str** | The path to a Content State .bin file relative to the project root | [optional] 
**linked_target_id** | **str** | The Id of the build target to obtain a Content State .bin file from | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


