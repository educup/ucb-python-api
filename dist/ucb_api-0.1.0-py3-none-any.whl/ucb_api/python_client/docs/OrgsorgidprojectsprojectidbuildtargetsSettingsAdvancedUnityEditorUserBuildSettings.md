# OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnityEditorUserBuildSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**android_build_system** | **str** | which android build system to build with (android only, supported in Unity 5.5+) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


