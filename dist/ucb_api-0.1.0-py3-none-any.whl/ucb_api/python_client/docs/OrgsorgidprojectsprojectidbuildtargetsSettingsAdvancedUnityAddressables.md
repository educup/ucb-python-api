# OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnityAddressables

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**build_addressables** | **bool** | enable addressable builds for this target | [optional] 
**content_update** | **bool** | Update a previously built player with new Addressable Content. | [optional] 
**profile_name** | **str** | which addressables profile should be used for the build | [optional] 
**failed_addressables_fails_build** | **bool** | Exit and mark the build as failed if an error occurs when addressables are built | [optional] [default to True]
**content_update_settings** | [**OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnityAddressablesContentUpdateSettings**](OrgsorgidprojectsprojectidbuildtargetsSettingsAdvancedUnityAddressablesContentUpdateSettings.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


