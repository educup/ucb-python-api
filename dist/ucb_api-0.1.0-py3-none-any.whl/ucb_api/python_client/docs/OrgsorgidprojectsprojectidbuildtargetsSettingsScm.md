# OrgsorgidprojectsprojectidbuildtargetsSettingsScm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] 
**repo** | **str** | Which repo to use. Only applies to Plastic SCM, other SCM types configure repo on the project level. | [optional] 
**branch** | **str** |  | [optional] 
**subdirectory** | **str** | subdirectory to build from | [optional] 
**client** | **str** | perforce only client workspace to build from | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


